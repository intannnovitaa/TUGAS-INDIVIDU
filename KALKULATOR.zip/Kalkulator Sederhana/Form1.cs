﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulator_Sederhana
{
    public partial class Form1 : Form
    {
        private float tampungOpr = 0;
        private string opr = " ";

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "1";
            }
            else
            {
                tampil = tampil + "1";
            }
            tbhasil.Text = tampil;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "2";
            }
            else
            {
                tampil = tampil + "2";
            }
            tbhasil.Text = tampil;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "3";
            }
            else
            {
                tampil = tampil + "3";
            }
            tbhasil.Text = tampil;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "4";
            }
            else
            {
                tampil = tampil + "4";
            }
            tbhasil.Text = tampil;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "5";
            }
            else
            {
                tampil = tampil + "5";
            }
            tbhasil.Text = tampil;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "6";
            }
            else
            {
                tampil = tampil + "6";
            }
            tbhasil.Text = tampil;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "7";
            }
            else
            {
                tampil = tampil + "7";
            }
            tbhasil.Text = tampil;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "8";
            }
            else
            {
                tampil = tampil + "8";
            }
            tbhasil.Text = tampil;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "9";
            }
            else
            {
                tampil = tampil + "9";
            }
            tbhasil.Text = tampil;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = "0";
            }
            else
            {
                tampil = tampil + "0";
            }
            tbhasil.Text = tampil;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string tampil = tbhasil.Text;
            if (tampil == "")
            {
                tampil = ".";
            }
            else
            {
                tampil = tampil + ".";
            }
            tbhasil.Text = tampil;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            float tampil = Convert.ToInt32(tbhasil.Text);
            this.tampungOpr = tampil;
            this.opr = "+";
            tbhasil.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            float tampil = Convert.ToInt32(tbhasil.Text);
            this.tampungOpr = tampil;
            this.opr = "/";
            tbhasil.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            float tampil = Convert.ToInt32(tbhasil.Text);
            this.tampungOpr = tampil;
            this.opr = "*";
            tbhasil.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            float tampil = Convert.ToInt32(tbhasil.Text);
            this.tampungOpr = tampil;
            this.opr = "-";
            tbhasil.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            tbhasil.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            float hasil = 0;
            float tampil = 0;
            if (tbhasil.Text.Equals(""))
            {
                tampil = 0;
            }
            else
            {
                tampil = Convert.ToInt32(tbhasil.Text);
            }

            if (this.opr == "+")
            {
                hasil = this.tampungOpr + tampil;
            }
            else if (this.opr == "-")
            {
                hasil = this.tampungOpr - tampil;
            }
            else if (this.opr == "/")
            {
                hasil = this.tampungOpr / tampil;
            }
            else if (this.opr == "*")
            {
                hasil = this.tampungOpr * tampil;
            }
            tbhasil.Text = Convert.ToString(hasil);
            this.tampungOpr = tampil;
            this.opr = "";



        }
    }
}
